# Online E-Commerce Platform (Java)
Console-based OOP project with Admin, Seller and Buyer dashboards.

## Run locally
Install JDK 8+; open a terminal in this folder:
```bash
cd src
javac *.java
java Main
```
## Demo accounts
- Admin: admin@shop.com / admin123
- Seller: seller@shop.com / seller123
- Buyer: buyer@shop.com / buyer123

## Included
Role-based login, buyer registration, user management, product CRUD, seller inventory, search, cart, checkout simulation, stock validation, order history/status tracking, wishlist and activity log.

## Limitations
Data is stored in memory and resets on exit. This is a learning prototype, not production-ready. Passwords are plain text. Real payment processing, database persistence, address book, and graphical charts are not included.
