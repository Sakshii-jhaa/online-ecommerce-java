public class Product {
 private final int id,sellerId; private String name,description; private double price; private int stock;
 public Product(int i,String n,String d,double p,int q,int s){id=i;name=n;description=d;price=p;stock=q;sellerId=s;}
 public int getId(){return id;} public int getSellerId(){return sellerId;} public String getName(){return name;}
 public String getDescription(){return description;} public double getPrice(){return price;} public int getStock(){return stock;}
 public void setName(String n){name=n;} public void setDescription(String d){description=d;}
 public void setPrice(double p){price=p;} public void setStock(int q){stock=q;}
 public String toString(){return "ID:"+id+" | "+name+" | Rs."+String.format("%.2f",price)+" | Stock:"+stock+" | "+description;}
}