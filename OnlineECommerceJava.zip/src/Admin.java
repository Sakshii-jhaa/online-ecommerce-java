public class Admin extends User {
 public Admin(int i,String n,String e,String p){super(i,n,e,p,"ADMIN");}
 public void dashboardTitle(){System.out.println("\\n=== ADMIN DASHBOARD ===");}
}