import java.util.Scanner;
public class Main {
 public static void main(String[] args) {
  ECommerceSystem app = new ECommerceSystem(); app.seed();
  Scanner sc = new Scanner(System.in); boolean run = true;
  System.out.println("=== ONLINE E-COMMERCE PLATFORM ===");
  System.out.println("Demo logins: admin@shop.com/admin123 | seller@shop.com/seller123 | buyer@shop.com/buyer123");
  while(run) {
   System.out.println("\\n1.Login  2.Register Buyer  3.Browse Products  0.Exit");
   int c=Input.integer(sc,"Choose: ");
   switch(c) {
    case 1:
     User u=app.login(Input.line(sc,"Email: "),Input.line(sc,"Password: "));
     if(u==null) System.out.println("Invalid login.");
     else if(u instanceof Admin) app.admin(sc,(Admin)u);
     else if(u instanceof Seller) app.seller(sc,(Seller)u);
     else app.buyer(sc,(Buyer)u);
     break;
    case 2:
     System.out.println(app.register(Input.line(sc,"Name: "),Input.line(sc,"Email: "),Input.line(sc,"Password (4+ chars): "))?"Registered.":"Registration failed; check details/email.");
     break;
    case 3: app.showProducts(); break;
    case 0: run=false; break;
    default: System.out.println("Invalid choice.");
   }
  }
  System.out.println("Goodbye!"); sc.close();
 }
}