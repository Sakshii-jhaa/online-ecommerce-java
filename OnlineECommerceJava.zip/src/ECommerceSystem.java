import java.util.*;
public class ECommerceSystem {
 private final List<User> users=new ArrayList<>(); private final List<Product> products=new ArrayList<>();
 private final List<Order> orders=new ArrayList<>(); private final List<String> logs=new ArrayList<>();
 private int uid=1,pid=1,oid=1;
 public void seed(){
  users.add(new Admin(uid++,"Administrator","admin@shop.com","admin123"));
  Seller s=new Seller(uid++,"Demo Seller","seller@shop.com","seller123");users.add(s);
  users.add(new Buyer(uid++,"Demo Buyer","buyer@shop.com","buyer123"));
  addProduct(s,"Wireless Mouse","Wireless optical mouse",599,20);
  addProduct(s,"Notebook","A5 ruled notebook",80,100);
  addProduct(s,"Headphones","Wired stereo headphones",799,15);
  logs.add("Demo data initialized.");
 }
 public User login(String e,String p){for(User u:users)if(u.getEmail().equalsIgnoreCase(e)&&u.getPassword().equals(p)){logs.add("Login: "+e);return u;}return null;}
 public boolean register(String n,String e,String p){if(n.isEmpty()||!e.contains("@")||p.length()<4)return false;for(User u:users)if(u.getEmail().equalsIgnoreCase(e))return false;users.add(new Buyer(uid++,n,e,p));logs.add("Buyer registered: "+e);return true;}
 private User user(int id){for(User u:users)if(u.getId()==id)return u;return null;}
 private Product product(int id){for(Product p:products)if(p.getId()==id)return p;return null;}
 private Order order(int id){for(Order o:orders)if(o.getId()==id)return o;return null;}
 private void log(String s){logs.add(new Date()+" - "+s);}
 private void addProduct(Seller s,String n,String d,double price,int q){products.add(new Product(pid++,n,d,price,q,s.getId()));}
 public void showProducts(){System.out.println("\\n--- PRODUCTS ---");if(products.isEmpty())System.out.println("No products.");for(Product p:products)System.out.println(p);}
 private void createProduct(Scanner sc,Seller s){String n=Input.line(sc,"Product name: "),d=Input.line(sc,"Description: ");double p=Input.decimal(sc,"Price: ");int q=Input.integer(sc,"Stock: ");if(n.isEmpty()||q<0){System.out.println("Invalid details.");return;}addProduct(s,n,d,p,q);log("Product added: "+n);System.out.println("Product listed.");}
 private void editProduct(Scanner sc,Seller s,boolean admin){int id=Input.integer(sc,"Product ID: ");Product p=product(id);if(p==null||(!admin&&p.getSellerId()!=s.getId())){System.out.println("Product not found.");return;}String n=Input.line(sc,"Name: "),d=Input.line(sc,"Description: ");double price=Input.decimal(sc,"Price: ");int q=Input.integer(sc,"Stock: ");if(n.isEmpty()||q<0){System.out.println("Invalid details.");return;}p.setName(n);p.setDescription(d);p.setPrice(price);p.setStock(q);log("Product updated: "+id);System.out.println("Product updated.");}
 public void admin(Scanner sc,Admin a){boolean done=false;while(!done){a.dashboardTitle();System.out.println("1.Users 2.Add Seller 3.Edit User 4.Delete User 5.Products 6.Add Product 7.Edit Product 8.Delete Product 9.Orders/Update 10.Activity Log 0.Logout");int c=Input.integer(sc,"Choose: ");switch(c){
 case 1:for(User u:users)System.out.println(u.getId()+" | "+u.getName()+" | "+u.getEmail()+" | "+u.getRole());break;
 case 2:{String n=Input.line(sc,"Name: "),e=Input.line(sc,"Email: "),p=Input.line(sc,"Password: ");if(n.isEmpty()||!e.contains("@")||p.length()<4||exists(e))System.out.println("Invalid details/email exists.");else{users.add(new Seller(uid++,n,e,p));log("Seller created: "+e);System.out.println("Seller created.");}break;}
 case 3:{int id=Input.integer(sc,"User ID: ");User u=user(id);if(u==null||u instanceof Admin){System.out.println("User not found/protected.");break;}String n=Input.line(sc,"New name: "),e=Input.line(sc,"New email: ");if(n.isEmpty()||!e.contains("@")||existsOther(e,id))System.out.println("Invalid details.");else{u.setName(n);u.setEmail(e);log("User updated: "+id);System.out.println("Updated.");}break;}
 case 4:{int id=Input.integer(sc,"User ID: ");User u=user(id);if(u==null||u instanceof Admin)System.out.println("User not found/protected.");else{users.remove(u);products.removeIf(p->p.getSellerId()==id);log("User deleted: "+id);System.out.println("User deleted.");}break;}
 case 5:showProducts();break;
 case 6:{int id=Input.integer(sc,"Seller ID: ");User u=user(id);if(u instanceof Seller)createProduct(sc,(Seller)u);else System.out.println("Seller not found.");break;}
 case 7:editProduct(sc,null,true);break;
 case 8:{int id=Input.integer(sc,"Product ID: ");Product p=product(id);if(p==null)System.out.println("Not found.");else{products.remove(p);log("Product deleted: "+id);System.out.println("Deleted.");}break;}
 case 9:showOrders(true,null);updateStatus(sc,true,null);break;
 case 10:for(String l:logs)System.out.println(l);break;case 0:done=true;break;default:System.out.println("Invalid choice.");}}}
 private boolean exists(String e){for(User u:users)if(u.getEmail().equalsIgnoreCase(e))return true;return false;}
 private boolean existsOther(String e,int id){for(User u:users)if(u.getId()!=id&&u.getEmail().equalsIgnoreCase(e))return true;return false;}
 public void seller(Scanner sc,Seller s){boolean done=false;while(!done){s.dashboardTitle();System.out.println("1.My Products 2.Add Product 3.Edit/Inventory 4.View Orders 5.Process Order 6.Sales Summary 0.Logout");int c=Input.integer(sc,"Choose: ");switch(c){
 case 1:for(Product p:products)if(p.getSellerId()==s.getId())System.out.println(p);break;case 2:createProduct(sc,s);break;case 3:editProduct(sc,s,false);break;case 4:showOrders(false,s);break;case 5:updateStatus(sc,false,s);break;
 case 6:{double total=0;for(Order o:orders)if(!o.getStatus().equals("CANCELLED"))for(Map.Entry<Integer,Integer> e:o.getItems().entrySet()){Product p=product(e.getKey());if(p!=null&&p.getSellerId()==s.getId())total+=p.getPrice()*e.getValue();}System.out.printf("Approximate sales: Rs. %.2f%n",total);break;}
 case 0:done=true;break;default:System.out.println("Invalid choice.");}}}
 public void buyer(Scanner sc,Buyer b){Map<Integer,Integer> cart=new LinkedHashMap<>();boolean done=false;while(!done){b.dashboardTitle();System.out.println("1.Browse 2.Search 3.Add to Cart 4.View Cart 5.Place Order 6.Order History/Track 7.Wishlist 0.Logout");int c=Input.integer(sc,"Choose: ");switch(c){
 case 1:showProducts();break;case 2:{String term=Input.line(sc,"Search: ").toLowerCase();for(Product p:products)if(p.getName().toLowerCase().contains(term)||p.getDescription().toLowerCase().contains(term))System.out.println(p);break;}
 case 3:{showProducts();int id=Input.integer(sc,"Product ID: "),q=Input.integer(sc,"Quantity: ");Product p=product(id);if(p==null||q<=0||p.getStock()<cart.getOrDefault(id,0)+q)System.out.println("Invalid product/insufficient stock.");else{cart.put(id,cart.getOrDefault(id,0)+q);System.out.println("Added to cart.");}break;}
 case 4:showCart(cart);break;case 5:checkout(b,cart);break;case 6:showOrders(false,b);break;
 case 7:System.out.println("Wishlist: "+b.getWishlist());int id=Input.integer(sc,"Product ID (0 cancel): ");if(id!=0&&product(id)!=null){b.getWishlist().add(id);System.out.println("Added.");}else if(id!=0)System.out.println("Product not found.");break;
 case 0:done=true;break;default:System.out.println("Invalid choice.");}}}
 private void showCart(Map<Integer,Integer> cart){double total=0;if(cart.isEmpty())System.out.println("Cart empty.");for(Map.Entry<Integer,Integer> e:cart.entrySet()){Product p=product(e.getKey());if(p!=null){double sub=p.getPrice()*e.getValue();total+=sub;System.out.printf("%s x %d = Rs. %.2f%n",p.getName(),e.getValue(),sub);}}System.out.printf("Total: Rs. %.2f%n",total);}
 private void checkout(Buyer b,Map<Integer,Integer> cart){if(cart.isEmpty()){System.out.println("Cart empty.");return;}double total=0;for(Map.Entry<Integer,Integer> e:cart.entrySet()){Product p=product(e.getKey());if(p==null||p.getStock()<e.getValue()){System.out.println("Stock unavailable; review cart.");return;}total+=p.getPrice()*e.getValue();}for(Map.Entry<Integer,Integer> e:cart.entrySet()){Product p=product(e.getKey());p.setStock(p.getStock()-e.getValue());}orders.add(new Order(oid++,b.getId(),cart,total));cart.clear();log("Order placed by buyer "+b.getId());System.out.printf("Order placed! Total: Rs. %.2f%n",total);}
 private boolean sellerOwns(Order o,Seller s){for(int id:o.getItems().keySet()){Product p=product(id);if(p!=null&&p.getSellerId()==s.getId())return true;}return false;}
 private void showOrders(boolean all,User u){boolean found=false;for(Order o:orders)if(all||(u instanceof Buyer&&o.getBuyerId()==u.getId())||(u instanceof Seller&&sellerOwns(o,(Seller)u))){System.out.println(o);found=true;}if(!found)System.out.println("No matching orders.");}
 private void updateStatus(Scanner sc,boolean admin,Seller seller){int id=Input.integer(sc,"Order ID (0 cancel): ");if(id==0)return;Order o=order(id);if(o==null||(!admin&&(seller==null||!sellerOwns(o,seller)))){System.out.println("Order not found.");return;}System.out.println("1.PROCESSING 2.SHIPPED 3.DELIVERED 4.CANCELLED");int c=Input.integer(sc,"Status: ");String[] states={"","PROCESSING","SHIPPED","DELIVERED","CANCELLED"};if(c<1||c>4)System.out.println("Invalid status.");else{o.setStatus(states[c]);log("Order "+id+" -> "+states[c]);System.out.println("Status updated.");}}
}