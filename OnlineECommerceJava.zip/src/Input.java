import java.util.Scanner;
public class Input {
 public static String line(Scanner s,String p){System.out.print(p);return s.nextLine().trim();}
 public static int integer(Scanner s,String p){while(true){try{return Integer.parseInt(line(s,p));}catch(Exception e){System.out.println("Enter a whole number.");}}}
 public static double decimal(Scanner s,String p){while(true){try{double d=Double.parseDouble(line(s,p));if(d>0 && Double.isFinite(d))return d;}catch(Exception e){}System.out.println("Enter a valid positive number.");}}
}