public abstract class User {
 private final int id; private String name,email,password; private final String role;
 public User(int i,String n,String e,String p,String r){id=i;name=n;email=e;password=p;role=r;}
 public int getId(){return id;} public String getName(){return name;} public String getEmail(){return email;}
 public String getPassword(){return password;} public String getRole(){return role;}
 public void setName(String n){name=n;} public void setEmail(String e){email=e;}
 public abstract void dashboardTitle();
}