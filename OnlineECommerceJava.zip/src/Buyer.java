import java.util.ArrayList;
public class Buyer extends User {
 private final ArrayList<Integer> wishlist=new ArrayList<>();
 public Buyer(int i,String n,String e,String p){super(i,n,e,p,"BUYER");}
 public ArrayList<Integer> getWishlist(){return wishlist;}
 public void dashboardTitle(){System.out.println("\\n=== BUYER DASHBOARD ===");}
}