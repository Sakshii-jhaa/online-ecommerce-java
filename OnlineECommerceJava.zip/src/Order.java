import java.util.LinkedHashMap; import java.util.Map;
public class Order {
 private final int id,buyerId; private final Map<Integer,Integer> items; private final double total; private String status="PLACED";
 public Order(int i,int b,Map<Integer,Integer> it,double t){id=i;buyerId=b;items=new LinkedHashMap<>(it);total=t;}
 public int getId(){return id;} public int getBuyerId(){return buyerId;} public Map<Integer,Integer> getItems(){return new LinkedHashMap<>(items);}
 public double getTotal(){return total;} public String getStatus(){return status;} public void setStatus(String s){status=s;}
 public String toString(){return "Order #"+id+" | Buyer ID:"+buyerId+" | Total: Rs."+String.format("%.2f",total)+" | "+status;}
}