public class Seller extends User {
 public Seller(int i,String n,String e,String p){super(i,n,e,p,"SELLER");}
 public void dashboardTitle(){System.out.println("\\n=== SELLER DASHBOARD ===");}
}